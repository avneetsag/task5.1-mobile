package com.example.task51;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>
{
    desplaces[] listplaces;
    Context context;


    public RecyclerViewAdapter(desplaces[] listplaces, MainActivity activity) {
        this.listplaces = listplaces;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.places,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
       final desplaces placeList  = listplaces[position];
        holder.textView.setText(placeList.getDestitle());
        holder.textview2.setText(placeList.getDesdescription());
        holder.imageView3.setImageResource(placeList.getDesimage());

        holder.itemView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(placeList.getDestitle() == "Paris")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    paris parisFragment = new paris();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.contraint, parisFragment).addToBackStack(null).commit();
                }
                else if(placeList.getDestitle() == "Dubai")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    bora_bora dubaiFragment = new bora_bora();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.contraint, dubaiFragment).addToBackStack(null).commit();

                }

                else if(placeList.getDestitle() == "Melbourne")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    glacier_national_park melbourneFragment = new glacier_national_park();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.contraint,melbourneFragment).addToBackStack(null).commit();

                }

                else if(placeList.getDestitle() == "Sydney")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    maui sydneyFragment = new maui();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.contraint, sydneyFragment).addToBackStack(null).commit();

                }

                else if(placeList.getDestitle() == "Chandigarh")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    south_island chandigarhFragment = new south_island();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.contraint, chandigarhFragment).addToBackStack(null).commit();

                }

                else
                {
                    Toast.makeText(context, placeList.getDestitle(), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    @Override
    public int getItemCount() {
        return listplaces.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView textView;
        TextView textview2;
        ImageView imageView3;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textView);
            textview2 = itemView.findViewById(R.id.textview2);
            imageView3 = itemView.findViewById(R.id.imageView3);
        }
    }
}
